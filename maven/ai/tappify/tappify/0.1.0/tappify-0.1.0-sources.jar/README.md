# Tappify binary SDK

This sources artifact intentionally contains only this README. Tappify's Kotlin
and Java implementation is proprietary and is not distributed as source.
The matching javadoc artifact contains generated public JVM API reference,
including Compose compiler lowered signatures. Installation and support:
https://github.com/tappify-dev/tappify-android-dist
